#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLabel>
#include <QRect>
#include <QString>
#include <QTextBrowser>
#include <QInputDialog>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>

QList<QLabel*> Images;
int free_index = 0;
bool showPrecise = true; //if set to true, shows the count of each type of card
bool showUsed = false; //if set to false, shows the cards left in the deck and if true, shows cards in hand and in discard
bool doubledDown = false;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QPixmap picBust("C:/Users/David/Documents/Qt/build-Blackjack3-Desktop_Qt_5_6_2_MinGW_32bit3-Debug/bust.jpg"); //Place the image location here for the "bust" image, use only '/' slashes
    QPixmap picWin("C:/Users/David/Documents/Qt/build-Blackjack3-Desktop_Qt_5_6_2_MinGW_32bit3-Debug/win.jpg");   //Place the image location here for the "win" image, use only '/' slashes
    QPixmap picLoss("C:/Users/David/Documents/Qt/build-Blackjack3-Desktop_Qt_5_6_2_MinGW_32bit3-Debug/dealerwon.png");   //Place the image location here for the "win" image, use only '/' slashes
    //image size should be 520x218

    ui->labelWin->setPixmap(picWin);
    ui->labelBust->setPixmap(picBust);
    ui->labelLoss->setPixmap(picLoss);

//USE THIS TO PLAY BUST
            QGraphicsOpacityEffect *eff = new QGraphicsOpacityEffect(this);
            ui->labelBust->setGraphicsEffect(eff);
            QPropertyAnimation *a = new QPropertyAnimation(eff,"opacity");
            a->setDuration(5000);
            a->setStartValue(0); //change this to 1
            a->setEndValue(0);
            a->start(QPropertyAnimation::DeleteWhenStopped);

// USE THIS TO PLAY WIN
            QGraphicsOpacityEffect *eff2 = new QGraphicsOpacityEffect(this);
            ui->labelWin->setGraphicsEffect(eff2);
            QPropertyAnimation *b = new QPropertyAnimation(eff2,"opacity");
            b->setDuration(5000);
            b->setStartValue(0); //change this to 1
            b->setEndValue(0);
            b->start(QPropertyAnimation::DeleteWhenStopped);

// USE THIS TO PLAY LOSS
            QGraphicsOpacityEffect *eff3 = new QGraphicsOpacityEffect(this);
            ui->labelLoss->setGraphicsEffect(eff3);
            QPropertyAnimation *c = new QPropertyAnimation(eff3,"opacity");
            c->setDuration(5000);
            c->setStartValue(0); //change this to 1
            c->setEndValue(0);
            c->start(QPropertyAnimation::DeleteWhenStopped);

    Chip_name = "Poker_Chip.png";
    //Change_user("BOB");
    for (int i = 0; i < 52; ++i)
    {
        Images.push_back(new QLabel(this));
    }

    for (int i = 0; i < 3; ++i)
    {
        Chip_Values.push_back(new QTextBrowser(this));
    }
    Chip_Values[2]->hide();
    Title_Message = "BlackJack Game: Version 2.2";
    this->setWindowTitle(Title_Message);
    Deck.addStandardDeck(1);
    Deck.Shuffle();
	Human = Player(false);
	Dealer = Player(true);
    Start_Game();
}


void MainWindow::Update_Card_Count()
{
    Deck.setRemainingUsed(!showUsed);
    if (!showUsed)
    {
        if (showPrecise)
        {
            ui->textBrowser_2->setText(QString("Aces remaining: ") + QString::number(Deck.getCardCount(0)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nTwos remaining: ") + QString::number(Deck.getCardCount(1)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nThrees remaining: ") + QString::number(Deck.getCardCount(2)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nFours remaining: ") + QString::number(Deck.getCardCount(3)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nFives remaining: ") + QString::number(Deck.getCardCount(4)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nSixes remaining: ") + QString::number(Deck.getCardCount(5)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nSevens remaining: ") + QString::number(Deck.getCardCount(6)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nEights remaining: ") + QString::number(Deck.getCardCount(7)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nNines remaining: ") + QString::number(Deck.getCardCount(8)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nTens remaining: ") + QString::number(Deck.getCardCount(9)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nJacks remaining: ") + QString::number(Deck.getCardCount(10)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nQueens remaining: ") + QString::number(Deck.getCardCount(11)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nKings remaining: ") + QString::number(Deck.getCardCount(12)));
        }
        else
        {
            ui->textBrowser_2->setText(QString("Low Cards (A-7) remaining: ") + QString::number(Deck.getLowCount()));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nHigh Cards(8 - K) remaining: ") + QString::number(Deck.getHighCount()));
        }
    }
    else
    {
        if (showPrecise)
        {
            ui->textBrowser_2->setText(QString("Aces used: ") + QString::number(Deck.getCardCount(0)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nTwos used: ") + QString::number(Deck.getCardCount(1)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nThrees used: ") + QString::number(Deck.getCardCount(2)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nFours used: ") + QString::number(Deck.getCardCount(3)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nFives used: ") + QString::number(Deck.getCardCount(4)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nSixes used: ") + QString::number(Deck.getCardCount(5)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nSevens used: ") + QString::number(Deck.getCardCount(6)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nEights used: ") + QString::number(Deck.getCardCount(7)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nNines used: ") + QString::number(Deck.getCardCount(8)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nTens used: ") + QString::number(Deck.getCardCount(9)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nJacks used: ") + QString::number(Deck.getCardCount(10)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nQueens used: ") + QString::number(Deck.getCardCount(11)));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nKings used: ") + QString::number(Deck.getCardCount(12)));
        }
        else
        {
            ui->textBrowser_2->setText(QString("Low Cards (A-7) used: ") + QString::number(Deck.getLowCount()));
            ui->textBrowser_2->setText(ui->textBrowser_2->toPlainText() + QString("\nHigh Cards(8 - K) used: ") + QString::number(Deck.getHighCount()));
        }
    }

}

void MainWindow::Start_Game()
{
    ui->New_Game->hide();
    ui->Split_Button->hide();
    ui->Double_Down->hide();
    ui->Surrender->show();
    for (int i = 0; i < 5; ++i)
    {
        Poker_Chips.push_back(new QLabel(this));
        Poker_Chips[i]->setPixmap(Chip_name);
        Poker_Chips[i]->hide();
    }
    current_hand_number = 0;
    Dealers_Turn = false;
    Chips_coordinates = Human.Get_Poker_coordinates();

    Update_Card_Count();
    //Dealer.Display_Hands();
    //cout << "The player's cards are the following:" << endl;
    //Human.Display_Hands();
    ui->textBrowser->setText("It is currently the player's turn.");
    Human.Set_Total_ChipsAmount(500.00+gainslosses);
    double bet_amount;
        do
        {
            bet_amount = QInputDialog::getInt(this, "Bet_Value", "Please enter the bet amount you want to put in(Minimum $5.00)",5);
        }
        while (bet_amount < 5.00 || bet_amount > Human.Get_Total_ChipsAmount());
        Human.resetHands();
        Dealer.resetHands();
        Human.Add_Bet(bet_amount);
        for (int i = 0; i < 2; ++i)
        {
            Deck.draw(Human, 0); //Draws the first player and is their first hand
            Deck.draw(Dealer, 0, i == 1);
            if (i == 1)
                Dealer.Flip_Card(0);
        }

        Update_Card_Count();

    Chips_coordinates = Human.Get_Poker_coordinates();
    for (int i = 0; i < 2; ++i)
    {
        Poker_Chips[i]->setGeometry(Chips_coordinates[i].chip_coordinates);
    }

    Poker_Chips[0]->show();
    Poker_Chips[1]->show();
    Chip_Values[0]->setText(QString("Total_Chips: $" + QString::number(Human.Get_Total_ChipsAmount())));
    Chip_Values[0]->setGeometry(QRect(110, 400, 131, 31));
    Chip_Values[1]->setText(QString("$ " + QString::number(Chips_coordinates[1].total_amount)));
    QRect temp = Chips_coordinates[1].chip_coordinates;
    temp.setTop(temp.top() + 50);
    temp.setX(temp.x() - 20);
    temp.setWidth(70);
    temp.setHeight(20);
    Chip_Values[1]->setGeometry(temp);

    if (Human.Is_Splitable())
        ui->Split_Button->show();

    if (Human.Is_Double_Downable(current_hand_number))
        ui->Double_Down->show();
}

// This needs to check the hand size and needs to allow them to hit based on how many hands they have
void MainWindow::on_Hit_Button_clicked()
{
    if (Dealers_Turn)
        Deck.draw(Dealer, 0);
    else
    {
        if (ui->Split_Button->isVisible())
            ui->Split_Button->hide();
        if (ui->Surrender->isVisible())
            ui->Surrender->hide();

        Deck.draw(Human, current_hand_number);
        if (Human.Is_Double_Downable(current_hand_number))
            ui->Double_Down->show();
        else
            ui->Double_Down->hide();
    }
    if (Dealers_Turn)
    {
        if (Dealer.Is_Busted(0))
        {
            QGraphicsOpacityEffect *eff2 = new QGraphicsOpacityEffect(this);
            ui->labelWin->setGraphicsEffect(eff2);
            QPropertyAnimation *b = new QPropertyAnimation(eff2,"opacity");
            b->setDuration(5000);
            b->setStartValue(1);
            b->setEndValue(0);
            b->start(QPropertyAnimation::DeleteWhenStopped);
            ;//Dialog_Text = "Dealer Busted with a value of " + QString::number(Dealer.Get_Current_Hand_value(0)) + "\n";
        }
        else
            ;//Dialog_Text = "Dealers current hand value is " + QString::number(Dealer.Get_Current_Hand_value(0)) + "\n";
    }
    else
    {
        if (Human.Is_Busted(current_hand_number))
        {
            //Dialog_Text = "You Busted with a value of " + QString::number(Human.Get_Current_Hand_value(current_hand_number)) + "\n";
            //ui->textBrowser->setText("You Busted with a value of " + QString::number(Human.Get_Current_Hand_value(current_hand_number)) + "\n");
            ui->labelBust->show();
            QGraphicsOpacityEffect *eff2 = new QGraphicsOpacityEffect(this);
            ui->labelBust->setGraphicsEffect(eff2);
            QPropertyAnimation *b = new QPropertyAnimation(eff2,"opacity");
            b->setDuration(5000);
            b->setStartValue(1);
            b->setEndValue(0);
            b->start(QPropertyAnimation::DeleteWhenStopped);
            on_Stay_Button_clicked();
            gainslosses -= (Chips_coordinates[1].total_amount);
            return;
        }
        else
        {
            Dialog_Text = "Your current hand value is " + QString::number(Human.Get_Current_Hand_value(current_hand_number)) + "\n";
            ui->textBrowser->setText((QString)"Your current hand value is " + QString::number(Human.Get_Current_Hand_value(current_hand_number)) + (QString)"\n");
        }
    }


    if (!players_out)
    {
        Dialog_Text = Players_Turn + Dialog_Text;
        ui->textBrowser->setText(Dialog_Text);
    }
    Update_Card_Count();
}

void MainWindow::New_Game()
{
    Deck.Discard_Current_Cards();
    Poker_Chips[2]->hide();
    Poker_Chips.clear();
    Chip_Values[2]->hide();
    ui->textBrowser->setText(QString(""));
    Start_Game();
}

void MainWindow::on_Stay_Button_clicked()
{
    if (ui->Surrender->isVisible())
        ui->Surrender->hide();
    if (Dealers_Turn == true)
    {
        Dealers_Turn = false;
        Players_Turn = "It is currently the player's turn\n";
       Human.Show_Hand();
    }

    else
    {
        Dealers_Turn = true;
        int id = Dealer.Flip_Card(0);
        Deck.changeCardCount(id, -1);
        Players_Turn = "It is currently the dealers's turn\n";
        current_hand_number = 0;
        players_out = true;
        for (int i = 0; i < Human.Get_Hand_Count();++i)
        {
            if (!(Human.Is_Busted(i)))
            {
                players_out = false;
            }
        }

        if (players_out)
        {
            ui->textBrowser->setText("You Busted with a value of " + QString::number(Human.Get_Current_Hand_value(current_hand_number)) + "\nThe Dealer Won!\n");
            doubledDown = false;
            New_Game();
            return;
        }
        Update_Card_Count();

        while (Dealer.Get_Current_Hand_value(0) < 17)
        {
            on_Hit_Button_clicked();
            Players_Turn += "The Dealer has a Total of ";
            Players_Turn += QString::number(Dealer.Get_Current_Hand_value(0));
        }

        if (Dealer.Get_Current_Hand_value(0) > 21)
        {
            Players_Turn += "\nThe Dealer has Busted!\n";
            ui->textBrowser->setText(QString(Players_Turn));
            for (int i = 0; i < Human.Get_Hand_Count();++i)
            {
                if (!(Human.Is_Busted(i)) && !getSurrender())
                {
                    //we need to update the bet money at this point
                    ui->textBrowser->setText(ui->textBrowser->toPlainText() + QString("Player 1 hand ") + QString::number(i + 1) + QString(": won \n"));
                    gainslosses+=(Chips_coordinates[1].total_amount);

                    //Play win animation
                    QGraphicsOpacityEffect *eff2 = new QGraphicsOpacityEffect(this);
                    ui->labelWin->setGraphicsEffect(eff2);
                    QPropertyAnimation *b = new QPropertyAnimation(eff2,"opacity");
                    b->setDuration(5000);
                    b->setStartValue(1);
                    b->setEndValue(0);
                    b->start(QPropertyAnimation::DeleteWhenStopped);

                }
            }

        }
        else
        {
            int Dealer_total = Dealer.Get_Current_Hand_value(0);
            bool Dealer_Beat_someone = false;
            ui->textBrowser->setText(QString(""));
            for (int i = 0; i < Human.Get_Hand_Count(); ++i)
            {
                if (Dealer_total < Human.Get_Current_Hand_value(i) && Human.Get_Current_Hand_value(i) < 22 && !getSurrender())
                {
                    ui->textBrowser->setText(ui->textBrowser->toPlainText() + QString("Player 1 hand ") + QString::number(i + 1) + QString(": won \n"));
                    gainslosses+=(Chips_coordinates[1].total_amount);
                    if (doubledDown)
                    {
                        gainslosses+=(Chips_coordinates[1].total_amount);
                    }
                    //Play win animation
                    QGraphicsOpacityEffect *eff2 = new QGraphicsOpacityEffect(this);
                    ui->labelWin->setGraphicsEffect(eff2);
                    QPropertyAnimation *b = new QPropertyAnimation(eff2,"opacity");
                    b->setDuration(5000);
                    b->setStartValue(1);
                    b->setEndValue(0);
                    b->start(QPropertyAnimation::DeleteWhenStopped);
                }
                else
                    Dealer_Beat_someone = true;
            }
            if (Dealer_Beat_someone && !getSurrender())
            {
                gainslosses-=(Chips_coordinates[1].total_amount);
                if (doubledDown)
                {
                    gainslosses-=(Chips_coordinates[1].total_amount);
                }
                //Play loss animation

                ui->textBrowser->setText(ui->textBrowser->toPlainText() + QString("Dealer won"));

                QGraphicsOpacityEffect *eff3 = new QGraphicsOpacityEffect(this);
                ui->labelLoss->setGraphicsEffect(eff3);
                QPropertyAnimation *c = new QPropertyAnimation(eff3,"opacity");
                c->setDuration(5000);
                c->setStartValue(1);
                c->setEndValue(0);
                c->start(QPropertyAnimation::DeleteWhenStopped);

            }
        }
        setUserSurrender(false);
        doubledDown = false;
        New_Game();
    }
    {
        if (current_hand_number == (int)Human.Get_Hand_Count() - 1)
        {
            current_hand_number = 0;
            Human.Hide_Hand();
            //++current_player_number;
            Human.Show_Hand();
            Players_Turn = "It is currently the player's turn.\n";
        }
        else
        {
            ++current_hand_number;
            Players_Turn = "It is currently the player's turn.\nHand number " + QString::number(current_hand_number + 1);
        }
		ui->textBrowser->setText(Players_Turn);
    }
    ui->Split_Button->hide();
    ui->Double_Down->hide();
}

void MainWindow::on_Split_Button_clicked()
{
    if (Human.Get_Total_ChipsAmount() - Chips_coordinates[Chips_coordinates.size() - 1].total_amount > 0)
    {
        Human.Split();
        current_hand_number = 0;
        Chips_coordinates[1].total_amount *= 2;
        ui->Split_Button->hide();
        ui->Surrender->hide();
        Chips_coordinates = Human.Get_Poker_coordinates();
        QRect temp = Chips_coordinates[Chips_coordinates.size() - 1].chip_coordinates;
        temp.setTop(temp.top() + 50);
        temp.setWidth(70);
        temp.setHeight(20);
        Chip_Values[Chips_coordinates.size() - 1]->setGeometry(temp);
        Chip_Values[Chips_coordinates.size() - 1]->setText(QString("$ " + QString::number(Chips_coordinates[Chips_coordinates.size() - 1].total_amount)));
        Poker_Chips[Chips_coordinates.size() - 1]->setGeometry(Chips_coordinates[Chips_coordinates.size() - 1].chip_coordinates);
        Poker_Chips[Chips_coordinates.size() - 1]->show();
        Chip_Values[Chips_coordinates.size() - 1]->show();
        Chip_Values[0]->setText(QString("Total_Chips: $" + QString::number(Human.Get_Total_ChipsAmount())));
    }
    else
    {
        ui->textBrowser->setText(QString("You do not have enough money for a split"));
    }
}

void MainWindow::on_Double_Down_clicked()
{
    //Do the bet for doubling down
    if (Human.Get_Total_ChipsAmount() - Chips_coordinates[Chips_coordinates.size() - 1].total_amount > 0)
    {
        Deck.draw(Human, current_hand_number);
        //Human.Flip_Card(current_hand_number);
        doubledDown = true;
        ui->Double_Down->hide();

        if (Human.Get_Hand_Count() == 1)
        {
            Human.Double_Down();
            Chips_coordinates = Human.Get_Poker_coordinates();
            QRect temp = Chips_coordinates[Chips_coordinates.size() - 1].chip_coordinates;
            temp.setTop(temp.top() + 50);
            temp.setX(temp.x() + 30);
            temp.setWidth(70);
            temp.setHeight(20);
            Chip_Values[Chips_coordinates.size() - 1]->setGeometry(temp);
            Chip_Values[Chips_coordinates.size() - 1]->setText(QString("$ " + QString::number(Chips_coordinates[Chips_coordinates.size() - 1].total_amount)));
            Poker_Chips[Chips_coordinates.size() - 1]->setGeometry(Chips_coordinates[Chips_coordinates.size() - 1].chip_coordinates);
            Poker_Chips[Chips_coordinates.size() - 1]->show();
            Chip_Values[Chips_coordinates.size() - 1]->show();
            Chip_Values[0]->setText(QString("Total_Chips: $" + QString::number(Human.Get_Total_ChipsAmount())));
        }
        else
        {
            Human.Change_Bet(current_hand_number + 1, Chips_coordinates[Chips_coordinates.size() - 1].total_amount * 2);
            Chips_coordinates = Human.Get_Poker_coordinates();
            Chip_Values[current_hand_number + 1]->setText(QString("$ " + QString::number(Chips_coordinates[current_hand_number + 1].total_amount)));
            Chip_Values[0]->setText(QString("Total_Chips: $" + QString::number(Human.Get_Total_ChipsAmount())));
        }
        on_Stay_Button_clicked();
    }
    else
    {
        ui->textBrowser->setText(QString("You do not have enough money for Double Down"));
    }
}
const bool getSurrender();
void setUserSurrender(bool);

void MainWindow::on_Surrender_clicked()
{
        cout << "YOU LOST HALF OF YOUR MONEY!!!!!!!!" << endl;
        Chip_Values[0]->setText(QString("Total_Chips: $") + QString::number(Chips_coordinates[0].total_amount + (Chips_coordinates[1].total_amount / 2)));
        gainslosses-=(Chips_coordinates[1].total_amount/2);
        ui->textBrowser->setText("You Lost the game with half your money back");
        //New_Game();
        setUserSurrender(true);
        on_Stay_Button_clicked();
}

void MainWindow::on_New_Game_clicked()
{
    doubledDown = false;
    New_Game();
}

bool MainWindow::Change_user(string username)
{
    //To be implemented in 3rd iteration, excluded from class diagram
    return true;
}

void MainWindow::on_pushButton_clicked()
{
    //if the card count is visible, hide it. Otherwise, make it hidden
    if (ui->textBrowser_2->isVisible())
        ui->textBrowser_2->hide();
    else
        ui->textBrowser_2->show();

}

MainWindow::~MainWindow()
{
    for (int i = 0; i < Images.size(); ++i)
    {
        delete Images.takeAt(0);
    }
    delete ui;
}

