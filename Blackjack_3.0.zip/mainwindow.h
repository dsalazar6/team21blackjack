#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QString>
#include <QTextBrowser>
#include <vector>
#include <QPushButton>
#include "card.h"
#include "player.h"
#include "deck.h"

using namespace std;

namespace Ui
{
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    Ui::MainWindow *ui;

    // Stores all information about Player(s)
    vector<Player> players;

    // Stores information about the dealer. MUST REMAIN A VECTOR
    vector<Player> Dealer;

    vector<QTextBrowser*> Chip_Values;
    vector<QLabel*> Poker_Chips;
    vector<Poker_chips> Chips_coordinates;

    bool players_out;
    bool Dealers_Turn;
    int current_player_number;
    int current_hand_number;
    int Number_of_Players;
    int turns=1; //Patrick's modification
    bool surrender=false;
    int automatedBet= 0; //Patrick's automated bets, now starts off so the user is prompted for a bet on the first round
    int timerAmount;

    //For the tutorials
    bool tutorial_mode;
    int tutorial_counter;
    double preserving_bid;
    double bet_amount;
    QPushButton* exit;
    QPushButton* remaining;


    QString Chip_name;
    QString Title_Message;
    QString Players_Turn;
    QString Dialog_Text;

    deck Deck;


private slots:

    void Update_Card_Count();

    // Whenever the user clicks on Hit, it will call this function
    void on_Hit_Button_clicked();

    // Whenever the user clicks on Stay, it will call this function
    void on_Stay_Button_clicked();

    // Whenever the user clicks on Split, it will call this function
    void on_Split_Button_clicked();

    // Whenever the user wants to start a new game
    void on_New_Game_clicked();

    //Whenever the user clicks on Double_Down, it will call this function
    void on_Double_Down_clicked();

    void on_Surrender_clicked();

    void on_pushButton_clicked();

    /* Functions to change text colors for bust, surrender, win, and lose in the Settings - Color Settings
       on_actionBust_triggered()
       on_actionSurrender_triggered()
       on_actionWin_triggered()
       on_actionLose_triggered() */
    void on_actionBust_triggered();

    void on_actionSurrender_triggered();

    void on_actionWin_triggered();

    void on_actionLose_triggered();



    /* Functions to apply to the different Rule options of the game
       on_actionDouble_Down_triggered()
       on_actionDealer_Stays_on_triggered()
       on_actionSurrender_return_values_triggered()
       on_actionSplit_triggered() */
    void on_actionDouble_Down_triggered();

    void on_actionDealer_Stays_on_triggered();

    void on_actionSurrender_return_values_triggered();

    void on_actionSplit_triggered();

    // This function changes the auto bet value
    void on_actionChange_Autobet_triggered();

    // This function gives the player the option to switch from low/high card count or displaying of exact cards count
    void on_Advanced_clicked();

    //This changes between cards remaining and used
    void on_Remaining_clicked();

    //Runs the tutorial
    void on_actionTutorial_triggered();

    //Used only for when the tutorial is running
    void on_Exit_Button_clicked();

    // Saves Double Down min and max values, surrender return value, dealer stay on value, and text colors
    void on_actionSave_triggered();

public:
    explicit MainWindow(QWidget *parent = 0);
   double gainslosses=0;


   bool getSurrender()
   {
   return surrender;
   }

   void setUserSurrender(bool truefalse)
   {
       surrender=truefalse;
   }
    int get_Turn()
    {
        return turns;
    }
    void incrementTurn()
    {
        turns++;
    }

    //Could use two ints for Deck ammounts and player ammount
    void Create_Deck() { return; }

    // Starts the game over. Removes info about players, clears hands, and deletes all cards
    void New_Game();

    // This is called the first time when the game starts and whenever New_Game() is called
    void Start_Game();


    // Allows the player to change to a different username
    bool Change_user(string username);

    //Use for the tutorial
    void Tutorial();


    int getAutomatedBet()
    {
        return automatedBet;
    }
    void setAutoMatedBet(int value)
    {
        automatedBet = value;
    }



    ~MainWindow();

};

#endif // MAINWINDOW_H
