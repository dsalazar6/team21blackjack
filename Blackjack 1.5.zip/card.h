#ifndef CARD_H
#define CARD_H

using std::string;
#include <QString>

class Card
{
private:
    string name;
    int value;
    int minValue;
    bool minValueUsed;
    bool isHidden;

public:
    int cardId[2];
    Card() {
        name = "NULL";
        value = minValue = 0;
        minValueUsed = false;
        isHidden = false;
    }
    Card(string name, int minValue, int value)
    {
        this->name = name;
        this->minValue = minValue;
        this->value = value;
        this->minValueUsed = false;
        this->isHidden = false;
    }

    Card(int index)
    {
        index = index % 52;
        int suit = index / 13;
		cardId[0] = suit;
        string suitNames[4] = { "Hearts", "Spades", "Diamonds", "Clubs" };
        int temp_value = index % 13;
        cardId[1] = temp_value;
        string valueNames[13] = { "Ace of ", "Two of ", "Three of ", "Four of ", "Five of ", "Six of ", "Seven of ", "Eight of ", "Nine of ", "Ten of ", "Jack of ", "Queen of ", "King of " };
        if (temp_value == 0)
        {
            this -> minValue = 1;
            this -> value = 11;
        }
        else
        {
            if (temp_value <= 9)
            {
                this->minValue = 1 + temp_value;
                this->value = 1 + temp_value;
            }
            else
            {
                this->minValue = 10;
                this->value = 10;
            }
        }
        this->name = valueNames[temp_value] + suitNames[suit];
        this->minValueUsed = false;
    }

    string getName() {
        return this->name;
    }
    QString getFileName() {
        QString CardFile = QString::fromStdString(name + ".png");
        return CardFile;
    }

    int getMinValue()
    {
        return this->minValue;
    }
    int getValue() {
        if (minValueUsed)
        {
            return this->minValue;
        }
        return this->value;
    }
    bool getMinValueUsed()
    {
        return this->minValueUsed;
    }
    void resetValue()
    {
        minValueUsed = false;
    }
    void useMinValue()
    {
        minValueUsed = true;
    }

    // Return the value of card's hidden flag
    bool getHidden() {
        return isHidden;
    }

    // Change the hidden flag to true to hide the card from players
    void hideCard() {
        isHidden = true;
    }

    ~Card() {}
};





#endif // CARD_H


